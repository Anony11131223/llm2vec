---
permalink: /
layout: splash
header:
    overlay_color: rgb(237, 27, 47)
    actions:
        - label: "Paper"
          url: https://arxiv.org
          icon: "fas fa-book"
        - label: "Code"
          url: "https://github.com/"
          icon: "fab fa-github"
        - label: "Demo"
          url: "https://example.com"
          icon: "fas fa-laptop"
        - label: "Tweets"
          url: "https://twitter.com/"
          icon: "fab fa-twitter"
        - label: "Video"
          url: "https://youtube.com"
          icon: "fas fa-video"

title: "My project name"
excerpt: Firstname Lastname, Firstname Lastname, Firstname Lastname, Firstname Lastname, Firstname Lastname
---

## About this project

Here, you can write a short description of your project.